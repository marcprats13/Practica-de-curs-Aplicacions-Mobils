package com.example.tripletriad.model

/**
 * Conté l'estat complet de la partida en un moment donat.
 * És immutable (data class) per facilitar la gestió d'estat amb StateFlow.
 *
 * @param board             Tauler 3x3 com a llista de 9 elements (null = cel·la buida)
 * @param playerHand        Mà del jugador (cartes restants)
 * @param cpuHand           Mà de la CPU (cartes restants)
 * @param currentTurn       De qui és el torn actual
 * @param playerScore       Puntuació del jugador (cartes al tauler + a la mà)
 * @param cpuScore          Puntuació de la CPU (cartes al tauler + a la mà)
 * @param isGameOver        Si la partida ha acabat
 * @param winner            Guanyador de la partida (NONE = empat)
 * @param selectedCardIndex Índex de la carta seleccionada a la mà del jugador
 * @param timeRemaining     Temps restant en el torn (0 si el timer no és actiu)
 * @param moveLog           Llista de missatges del log de la partida
 * @param totalMovesCount   Nombre total de moviments fets
 */
data class GameState(
    val board: List<Card?> = List(9) { null },
    val playerHand: List<Card> = emptyList(),
    val cpuHand: List<Card> = emptyList(),
    val currentTurn: CardOwner = CardOwner.PLAYER,
    val playerScore: Int = 5,
    val cpuScore: Int = 5,
    val isGameOver: Boolean = false,
    val winner: CardOwner = CardOwner.NONE,
    val selectedCardIndex: Int? = null,
    val timeRemaining: Int = 0,
    val moveLog: List<String> = emptyList(),
    val totalMovesCount: Int = 0
)
