package com.example.tripletriad.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary          = PrimaryBlue,
    onPrimary        = OnPrimary,
    primaryContainer = PrimaryBlueDark,
    secondary        = SecondaryGold,
    onSecondary      = Color.Black,
    background       = BackgroundDark,
    onBackground     = OnBackground,
    surface          = SurfaceDark,
    onSurface        = OnSurface,
    surfaceVariant   = SurfaceCard,
    error            = Color(0xFFCF6679),
    onError          = Color.Black
)

@Composable
fun TripleTriadTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography  = Typography,
        content     = content
    )
}
