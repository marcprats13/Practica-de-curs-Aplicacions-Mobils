package com.example.tripletriad.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.example.tripletriad.R
import com.example.tripletriad.model.CardOwner
import com.example.tripletriad.navigation.Screen
import com.example.tripletriad.ui.components.CardComponent
import com.example.tripletriad.ui.components.GameBoardComponent
import com.example.tripletriad.ui.theme.*
import com.example.tripletriad.viewmodel.GameViewModel

/**
 * Pantalla principal de la partida.
 *
 * Mostra:
 *  - Mà de la CPU (cartes ocultes)
 *  - Tauler 3x3 interactiu
 *  - Mà del jugador (cartes seleccionables)
 *  - Informació de torn, puntuació i timer
 *
 * Quan la partida acaba ([GameState.isGameOver] == true), navega
 * automàticament a ResultScreen via [LaunchedEffect].
 *
 * Tota la lògica és al ViewModel; aquí només hi ha UI i navigació.
 */
@Composable
fun GameScreen(
    navController: NavHostController,
    viewModel: GameViewModel
) {
    val gameState by viewModel.gameState.collectAsState()
    val config    by viewModel.config.collectAsState()

    // ── Navegació automàtica al finalitzar la partida ─────────────────
    LaunchedEffect(gameState.isGameOver) {
        if (gameState.isGameOver) {
            navController.navigate(Screen.Result.route) {
                // Elimina Game del backstack: no es pot tornar a la partida acabada
                popUpTo(Screen.Game.route) { inclusive = true }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {

        // ══ CAPÇALERA: Puntuació + Torn + Timer ═══════════════════════
        GameHeader(
            playerAlias  = config.playerAlias,
            playerScore  = gameState.playerScore,
            cpuScore     = gameState.cpuScore,
            currentTurn  = gameState.currentTurn,
            timeRemaining = gameState.timeRemaining,
            timerEnabled = config.timerEnabled,
            maxTime      = config.maxTimeSeconds
        )

        // ══ MÀ DE LA CPU (cartes ocultes) ════════════════════════════
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text  = stringResource(R.string.game_cpu_hand, gameState.cpuHand.size),
                color = OnSurface,
                style = MaterialTheme.typography.labelSmall
            )
            Spacer(Modifier.height(4.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.horizontalScroll(rememberScrollState())
            ) {
                repeat(gameState.cpuHand.size) {
                    CardComponent(
                        card     = gameState.cpuHand[it],
                        isHidden = true,   // CPU cards shown face-down
                        cardSize = 56.dp
                    )
                }
                // Marcadors de posicions buides
                repeat(5 - gameState.cpuHand.size) {
                    CardComponent(card = null, cardSize = 56.dp)
                }
            }
        }

        // ══ TAULER 3x3 ═══════════════════════════════════════════════
        BoxWithConstraints(
            modifier          = Modifier.weight(1f),
            contentAlignment  = Alignment.Center
        ) {
            val boardSize = minOf(maxWidth, maxHeight, 320.dp)
            GameBoardComponent(
                board           = gameState.board,
                hasCardSelected = gameState.selectedCardIndex != null &&
                                  gameState.currentTurn == CardOwner.PLAYER,
                onCellClick     = { position -> viewModel.placeCard(position) },
                boardMaxSize    = boardSize
            )
        }

        // ══ MÀ DEL JUGADOR (cartes seleccionables) ═══════════════════
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text  = stringResource(R.string.game_player_hand, config.playerAlias, gameState.playerHand.size),
                color = OnSurface,
                style = MaterialTheme.typography.labelSmall
            )
            Spacer(Modifier.height(4.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.horizontalScroll(rememberScrollState())
            ) {
                gameState.playerHand.forEachIndexed { index, card ->
                    CardComponent(
                        card       = card,
                        isSelected = index == gameState.selectedCardIndex,
                        onClick    = {
                            // Selecciona carta si és el torn del jugador
                            if (gameState.currentTurn == CardOwner.PLAYER) {
                                viewModel.selectCard(index)
                            }
                        },
                        cardSize = 70.dp
                    )
                }
                // Posicions buides
                repeat(5 - gameState.playerHand.size) {
                    CardComponent(card = null, cardSize = 70.dp)
                }
            }
        }

        // Instrucció contextual
        if (!gameState.isGameOver) {
            Text(
                text  = if (gameState.currentTurn == CardOwner.PLAYER) {
                    if (gameState.selectedCardIndex == null)
                        stringResource(R.string.game_hint_select)
                    else
                        stringResource(R.string.game_hint_place)
                } else {
                    stringResource(R.string.game_hint_cpu)
                },
                color     = OnSurface.copy(alpha = 0.7f),
                fontSize  = 12.sp,
                textAlign = TextAlign.Center,
                modifier  = Modifier.padding(top = 4.dp)
            )
        }
    }
}

// ──────────────────────────────────────────────────────────────────────
// CAPÇALERA DEL JOC
// ──────────────────────────────────────────────────────────────────────

@Composable
private fun GameHeader(
    playerAlias: String,
    playerScore: Int,
    cpuScore: Int,
    currentTurn: CardOwner,
    timeRemaining: Int,
    timerEnabled: Boolean,
    maxTime: Int
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors   = CardDefaults.cardColors(containerColor = SurfaceCard)
    ) {
        Column(
            modifier            = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // Puntuació
            Row(
                modifier              = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment     = Alignment.CenterVertically
            ) {
                ScoreBox(
                    label    = playerAlias,
                    score    = playerScore,
                    isActive = currentTurn == CardOwner.PLAYER,
                    color    = PlayerCardColor
                )

                Text(
                    text      = "VS",
                    color     = OnSurface,
                    fontSize  = 12.sp,
                    fontWeight = FontWeight.Bold
                )

                ScoreBox(
                    label    = "CPU",
                    score    = cpuScore,
                    isActive = currentTurn == CardOwner.CPU,
                    color    = CpuCardColor
                )
            }

            // Indicador de torn
            Text(
                text = if (currentTurn == CardOwner.PLAYER)
                    "→ Torn de $playerAlias"
                else
                    "→ Torn de la CPU...",
                color     = if (currentTurn == CardOwner.PLAYER) PlayerCardBorder else CpuCardBorder,
                fontSize  = 13.sp,
                fontWeight = FontWeight.SemiBold
            )

            // Timer (si activat)
            if (timerEnabled) {
                TimerBar(
                    timeRemaining = timeRemaining,
                    maxTime       = maxTime
                )
            }
        }
    }
}

@Composable
private fun ScoreBox(
    label: String,
    score: Int,
    isActive: Boolean,
    color: Color
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text       = label,
            color      = if (isActive) color else OnSurface,
            fontSize   = 13.sp,
            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal
        )
        Text(
            text       = score.toString(),
            color      = if (isActive) color else OnSurface.copy(alpha = 0.7f),
            fontSize   = 24.sp,
            fontWeight = FontWeight.ExtraBold
        )
    }
}

@Composable
private fun TimerBar(
    timeRemaining: Int,
    maxTime: Int
) {
    val progress  = if (maxTime > 0) timeRemaining.toFloat() / maxTime else 0f
    val timerColor = when {
        progress > 0.5f -> TimerNormal
        progress > 0.25f -> TimerWarning
        else             -> TimerDanger
    }

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text     = "⏱ ${timeRemaining}s",
            color    = timerColor,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
        )
        LinearProgressIndicator(
            progress       = { progress },
            modifier       = Modifier
                .fillMaxWidth()
                .height(6.dp),
            color          = timerColor,
            trackColor     = SurfaceDark
        )
    }
}
