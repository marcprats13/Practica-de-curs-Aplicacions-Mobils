package com.example.tripletriad.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.tripletriad.R
import com.example.tripletriad.ui.theme.*

/**
 * Pantalla d'ajuda amb les regles del joc.
 * Conté text estàtic amb la mecànica de Triple Triad.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HelpScreen(navController: NavHostController) {

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.screen_help_title)) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            imageVector        = Icons.Default.ArrowBack,
                            contentDescription = stringResource(R.string.cd_back)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SurfaceDark
                )
            )
        },
        containerColor = BackgroundDark
    ) { innerPadding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            HelpSection(
                title   = stringResource(R.string.help_section_objective),
                content = stringResource(R.string.help_content_objective)
            )
            HelpSection(
                title   = stringResource(R.string.help_section_cards),
                content = stringResource(R.string.help_content_cards)
            )
            HelpSection(
                title   = stringResource(R.string.help_section_turn),
                content = stringResource(R.string.help_content_turn)
            )
            HelpSection(
                title   = stringResource(R.string.help_section_capture),
                content = stringResource(R.string.help_content_capture)
            )
            HelpSection(
                title   = stringResource(R.string.help_section_end),
                content = stringResource(R.string.help_content_end)
            )
            HelpSection(
                title   = stringResource(R.string.help_section_timer),
                content = stringResource(R.string.help_content_timer)
            )

            Spacer(Modifier.height(8.dp))

            // Botó de tornar (alternatiu a la fletxa del topbar)
            OutlinedButton(
                onClick  = { navController.popBackStack() },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(stringResource(R.string.btn_back))
            }
        }
    }
}

@Composable
private fun HelpSection(title: String, content: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors   = CardDefaults.cardColors(containerColor = SurfaceCard)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text       = title,
                style      = MaterialTheme.typography.titleMedium,
                color      = SecondaryGold,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text  = content,
                style = MaterialTheme.typography.bodyMedium,
                color = OnBackground,
                lineHeight = MaterialTheme.typography.bodyMedium.lineHeight
            )
        }
    }
}
