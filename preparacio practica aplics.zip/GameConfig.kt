package com.example.tripletriad.model

/**
 * Configuració de la partida introduïda pel jugador a ConfigScreen.
 *
 * @param playerAlias       Àlies del jugador
 * @param timerEnabled      Si el temporitzador està activat
 * @param maxTimeSeconds    Temps màxim per torn en segons (si timerEnabled == true)
 */
data class GameConfig(
    val playerAlias: String = "Jugador",
    val timerEnabled: Boolean = false,
    val maxTimeSeconds: Int = 30
)
