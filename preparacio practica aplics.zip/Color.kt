package com.example.tripletriad.ui.theme

import androidx.compose.ui.graphics.Color

// ── Paleta principal (tema fosc inspirat en FF8) ─────────────────────
val PrimaryBlue      = Color(0xFF1565C0)
val PrimaryBlueDark  = Color(0xFF0D47A1)
val PrimaryBlueLight = Color(0xFF42A5F5)

val SecondaryGold    = Color(0xFFFFC107)
val SecondaryGoldDark = Color(0xFFF57F17)

val BackgroundDark   = Color(0xFF0A0E1A)
val SurfaceDark      = Color(0xFF121A2B)
val SurfaceCard      = Color(0xFF1C2740)

val OnPrimary        = Color(0xFFFFFFFF)
val OnBackground     = Color(0xFFE8EAF6)
val OnSurface        = Color(0xFFB0BEC5)

// ── Colors específics del joc ─────────────────────────────────────────
val PlayerCardColor  = Color(0xFF1565C0)   // Blau per al jugador
val CpuCardColor     = Color(0xFFC62828)   // Vermell per a la CPU
val NeutralCardColor = Color(0xFF37474F)   // Gris per a neutres

val PlayerCardBorder = Color(0xFF42A5F5)
val CpuCardBorder    = Color(0xFFEF9A9A)

val CellEmpty        = Color(0xFF1A2035)
val CellHover        = Color(0xFF2A3A55)
val BoardBackground  = Color(0xFF0D1520)

val TimerNormal      = Color(0xFF4CAF50)
val TimerWarning     = Color(0xFFFF9800)
val TimerDanger      = Color(0xFFF44336)

val WinColor         = Color(0xFFFFD700)
val LoseColor        = Color(0xFFEF5350)
val DrawColor        = Color(0xFF78909C)
