package com.example.tripletriad

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.navigation.compose.rememberNavController
import com.example.tripletriad.navigation.AppNavigation
import com.example.tripletriad.ui.theme.TripleTriadTheme
import com.example.tripletriad.viewmodel.GameViewModel

/**
 * Activity principal i única de l'aplicació.
 *
 * Responsabilitats:
 *  - Crear el ViewModel (Activity-scoped) perquè tots els Composable
 *    comparteixin la mateixa instància i sobrevivi a rotacions.
 *  - Configurar el tema Material3.
 *  - Inicialitzar el NavController i l'AppNavigation.
 *
 * NO hi ha lògica de joc aquí: tot és al GameViewModel.
 */
class MainActivity : ComponentActivity() {

    // ViewModel creat a nivell d'Activity: sobreviu a rotacions de pantalla
    private val gameViewModel: GameViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            TripleTriadTheme {
                val navController = rememberNavController()
                AppNavigation(
                    navController = navController,
                    viewModel     = gameViewModel
                )
            }
        }
    }
}
