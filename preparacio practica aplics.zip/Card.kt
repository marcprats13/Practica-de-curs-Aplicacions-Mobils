package com.example.tripletriad.model

/**
 * Representa el propietari d'una carta o del torn actual.
 */
enum class CardOwner {
    PLAYER, CPU, NONE
}

/**
 * Representa una carta del joc Triple Triad.
 *
 * @param id        Identificador únic de la carta
 * @param name      Nom de la carta
 * @param top       Valor superior (1-10)
 * @param right     Valor dret (1-10)
 * @param bottom    Valor inferior (1-10)
 * @param left      Valor esquerre (1-10)
 * @param owner     Propietari actual de la carta (PLAYER, CPU o NONE)
 */
data class Card(
    val id: Int,
    val name: String,
    val top: Int,
    val right: Int,
    val bottom: Int,
    val left: Int,
    val owner: CardOwner = CardOwner.NONE
)
