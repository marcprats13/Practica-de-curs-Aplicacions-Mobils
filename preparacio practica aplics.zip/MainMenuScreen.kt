package com.example.tripletriad.ui.screens

import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.example.tripletriad.R
import com.example.tripletriad.navigation.Screen
import com.example.tripletriad.ui.theme.*

/**
 * Pantalla principal de l'aplicació.
 *
 * Conté:
 *  - Títol del joc
 *  - Botó "Jugar" → navega a ConfigScreen
 *  - Botó "Ajuda" → navega a HelpScreen
 *  - Botó "Sortir" → tanca l'aplicació
 *
 * No hi ha lògica de negoci aquí: tot és navegació.
 */
@Composable
fun MainMenuScreen(navController: NavHostController) {
    val context = LocalContext.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(BackgroundDark, Color(0xFF0D1A2D))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 48.dp)
        ) {
            // ── Títol ──────────────────────────────────────────────────
            Text(
                text       = stringResource(R.string.app_title),
                fontSize   = 36.sp,
                fontWeight = FontWeight.Bold,
                color      = SecondaryGold,
                textAlign  = TextAlign.Center
            )

            Text(
                text      = stringResource(R.string.app_subtitle),
                fontSize  = 14.sp,
                color     = OnSurface,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(24.dp))

            // ── Botó Jugar ─────────────────────────────────────────────
            MenuButton(
                text    = stringResource(R.string.btn_play),
                onClick = {
                    navController.navigate(Screen.Config.route)
                }
            )

            // ── Botó Ajuda ─────────────────────────────────────────────
            MenuButton(
                text      = stringResource(R.string.btn_help),
                onClick   = { navController.navigate(Screen.Help.route) },
                isPrimary = false
            )

            // ── Botó Sortir ────────────────────────────────────────────
            OutlinedButton(
                onClick = { (context as? Activity)?.finish() },
                modifier = Modifier.fillMaxWidth(),
                colors   = ButtonDefaults.outlinedButtonColors(
                    contentColor = LoseColor
                )
            ) {
                Text(
                    text     = stringResource(R.string.btn_exit),
                    fontSize = 16.sp
                )
            }
        }
    }
}

/** Botó de menú reutilitzable. */
@Composable
private fun MenuButton(
    text: String,
    onClick: () -> Unit,
    isPrimary: Boolean = true
) {
    if (isPrimary) {
        Button(
            onClick  = onClick,
            modifier = Modifier.fillMaxWidth(),
            colors   = ButtonDefaults.buttonColors(
                containerColor = PrimaryBlue
            )
        ) {
            Text(text = text, fontSize = 16.sp)
        }
    } else {
        OutlinedButton(
            onClick  = onClick,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(text = text, fontSize = 16.sp)
        }
    }
}
