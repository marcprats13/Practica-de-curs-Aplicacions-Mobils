package com.example.tripletriad.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.example.tripletriad.R
import com.example.tripletriad.navigation.Screen
import com.example.tripletriad.ui.theme.*
import com.example.tripletriad.viewmodel.GameViewModel

/**
 * Pantalla de configuració de la partida.
 *
 * Permet configurar:
 *  - Àlies del jugador (TextField, requerit, no buit)
 *  - Activar/desactivar temporitzador (Checkbox)
 *  - Temps màxim per torn (visible i editable si timer és actiu)
 *
 * Validació d'errors inline (sense crashes).
 * Tota la lògica de configuració es delega al ViewModel.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConfigScreen(
    navController: NavHostController,
    viewModel: GameViewModel
) {
    val config by viewModel.config.collectAsState()

    // Estat local per al TextField de temps (per poder editar com a text)
    var timeText by remember { mutableStateOf(config.maxTimeSeconds.toString()) }
    var aliasError by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title  = { Text(stringResource(R.string.screen_config_title)) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            imageVector        = Icons.Default.ArrowBack,
                            contentDescription = stringResource(R.string.cd_back)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SurfaceDark
                )
            )
        },
        containerColor = BackgroundDark
    ) { innerPadding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // ── Secció: Jugador ────────────────────────────────────────
            SectionTitle(text = stringResource(R.string.config_section_player))

            OutlinedTextField(
                value         = config.playerAlias,
                onValueChange = { value ->
                    aliasError = value.isBlank()
                    viewModel.updatePlayerAlias(value)
                },
                label         = { Text(stringResource(R.string.config_alias_label)) },
                placeholder   = { Text(stringResource(R.string.config_alias_placeholder)) },
                isError       = aliasError,
                supportingText = {
                    if (aliasError) Text(
                        text  = stringResource(R.string.config_alias_error),
                        color = MaterialTheme.colorScheme.error
                    )
                },
                singleLine    = true,
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.Words,
                    imeAction      = ImeAction.Done
                ),
                modifier = Modifier.fillMaxWidth(),
                colors   = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor   = PrimaryBlueLight,
                    unfocusedBorderColor = OnSurface.copy(alpha = 0.4f)
                )
            )

            HorizontalDivider(color = OnSurface.copy(alpha = 0.2f))

            // ── Secció: Temporitzador ──────────────────────────────────
            SectionTitle(text = stringResource(R.string.config_section_timer))

            // Checkbox per activar/desactivar
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier          = Modifier.fillMaxWidth()
            ) {
                Checkbox(
                    checked         = config.timerEnabled,
                    onCheckedChange = { viewModel.updateTimerEnabled(it) },
                    colors          = CheckboxDefaults.colors(
                        checkedColor = PrimaryBlueLight
                    )
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text  = stringResource(R.string.config_timer_enable),
                    color = OnBackground,
                    style = MaterialTheme.typography.bodyLarge
                )
            }

            // Slider i TextField de temps (només visible si timer actiu)
            if (config.timerEnabled) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text  = stringResource(R.string.config_timer_label, config.maxTimeSeconds),
                        color = OnBackground,
                        style = MaterialTheme.typography.bodyMedium
                    )

                    Slider(
                        value         = config.maxTimeSeconds.toFloat(),
                        onValueChange = { value ->
                            val seconds = value.toInt()
                            viewModel.updateMaxTime(seconds)
                            timeText = seconds.toString()
                        },
                        valueRange    = 10f..120f,
                        steps         = 21,   // pas de 5 en 5
                        colors        = SliderDefaults.colors(
                            thumbColor       = SecondaryGold,
                            activeTrackColor = PrimaryBlueLight
                        )
                    )

                    // TextField manual per introduir valor exacte
                    OutlinedTextField(
                        value         = timeText,
                        onValueChange = { text ->
                            timeText = text
                            val parsed = text.toIntOrNull()
                            if (parsed != null) viewModel.updateMaxTime(parsed)
                        },
                        label         = { Text(stringResource(R.string.config_timer_seconds)) },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Number,
                            imeAction    = ImeAction.Done
                        ),
                        singleLine    = true,
                        modifier      = Modifier.width(140.dp),
                        colors        = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor   = PrimaryBlueLight,
                            unfocusedBorderColor = OnSurface.copy(alpha = 0.4f)
                        )
                    )

                    Text(
                        text  = stringResource(R.string.config_timer_range),
                        color = OnSurface,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }

            Spacer(Modifier.height(8.dp))

            // ── Botó Iniciar Partida ───────────────────────────────────
            Button(
                onClick  = {
                    // Validació final abans de navegar
                    if (config.playerAlias.isBlank()) {
                        aliasError = true
                        return@Button
                    }
                    viewModel.startGame()
                    navController.navigate(Screen.Game.route) {
                        // Elimina Config del backstack: si l'usuari prem enrere
                        // des de Game, no torna a Config sinó al MainMenu
                        popUpTo(Screen.Config.route) { inclusive = true }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                colors   = ButtonDefaults.buttonColors(
                    containerColor = PrimaryBlue
                )
            ) {
                Text(
                    text     = stringResource(R.string.btn_start_game),
                    fontSize = 17.sp
                )
            }
        }
    }
}

/** Títol de secció reutilitzable dins ConfigScreen */
@Composable
private fun SectionTitle(text: String) {
    Text(
        text  = text,
        style = MaterialTheme.typography.titleMedium,
        color = SecondaryGold
    )
}
