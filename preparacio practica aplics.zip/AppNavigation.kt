package com.example.tripletriad.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.tripletriad.ui.screens.*
import com.example.tripletriad.viewmodel.GameViewModel

/**
 * Rutes de l'aplicació.
 * Cada Screen encapsula la seva ruta com a String constant.
 */
sealed class Screen(val route: String) {
    object MainMenu : Screen("main_menu")
    object Config   : Screen("config")
    object Game     : Screen("game")
    object Result   : Screen("result")
    object Help     : Screen("help")
}

/**
 * Configura el NavHost principal de l'aplicació.
 *
 * - Usa [NavHost] de Navigation Compose
 * - Totes les pantalles comparteixen el mateix [GameViewModel] (Activity-scoped)
 * - La gestió del backstack s'especifica en cada navegació per evitar
 *   acumular pantalles indesitjades
 *
 * @param navController  Controlador de navegació
 * @param viewModel      ViewModel compartit entre pantalles
 */
@Composable
fun AppNavigation(
    navController: NavHostController,
    viewModel: GameViewModel
) {
    NavHost(
        navController    = navController,
        startDestination = Screen.MainMenu.route
    ) {
        // ── Menú principal ──────────────────────────────────────────────
        composable(Screen.MainMenu.route) {
            MainMenuScreen(navController = navController)
        }

        // ── Configuració ────────────────────────────────────────────────
        composable(Screen.Config.route) {
            ConfigScreen(
                navController = navController,
                viewModel     = viewModel
            )
        }

        // ── Partida ─────────────────────────────────────────────────────
        composable(Screen.Game.route) {
            GameScreen(
                navController = navController,
                viewModel     = viewModel
            )
        }

        // ── Resultats ───────────────────────────────────────────────────
        composable(Screen.Result.route) {
            ResultScreen(
                navController = navController,
                viewModel     = viewModel
            )
        }

        // ── Ajuda ───────────────────────────────────────────────────────
        composable(Screen.Help.route) {
            HelpScreen(navController = navController)
        }
    }
}
