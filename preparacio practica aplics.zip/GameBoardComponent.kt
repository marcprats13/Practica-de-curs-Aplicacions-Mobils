package com.example.tripletriad.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.tripletriad.model.Card
import com.example.tripletriad.ui.theme.BoardBackground
import com.example.tripletriad.ui.theme.CellEmpty
import com.example.tripletriad.ui.theme.CellHover
import com.example.tripletriad.ui.theme.SecondaryGold

/**
 * Tauler de joc 3x3 interactiu.
 *
 * Mostra les 9 cel·les del tauler:
 *  - Cel·les buides: fons fosc lleugerament visible
 *  - Cel·les ocupades: mostra la carta corresponent (CardComponent)
 *  - Cel·la ressaltada: quan el jugador ha seleccionat una carta
 *
 * @param board             Llista de 9 elements (null = buida)
 * @param hasCardSelected   Si el jugador té una carta seleccionada per col·locar
 * @param onCellClick       Callback quan el jugador prem una cel·la
 * @param boardMaxSize      Mida màxima del tauler (s'ajusta automàticament)
 */
@Composable
fun GameBoardComponent(
    board: List<Card?>,
    hasCardSelected: Boolean,
    onCellClick: (Int) -> Unit,
    boardMaxSize: Dp = 300.dp
) {
    // Calcula la mida de cada cel·la (tauler és 3x3 amb separadors)
    val gap      = 4.dp
    val cellSize = (boardMaxSize - gap * 4) / 3  // 3 cel·les + 4 marges

    Box(
        modifier = Modifier
            .background(BoardBackground, RoundedCornerShape(12.dp))
            .border(2.dp, Color(0xFF2A3A55), RoundedCornerShape(12.dp))
            .padding(gap)
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(gap),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 3 files
            for (row in 0..2) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(gap)
                ) {
                    // 3 columnes
                    for (col in 0..2) {
                        val position = row * 3 + col
                        val cellCard = board.getOrNull(position)
                        val isEmpty  = cellCard == null
                        val isHoverable = isEmpty && hasCardSelected

                        BoardCell(
                            card       = cellCard,
                            isDropTarget = isHoverable,
                            cellSize   = cellSize,
                            onClick    = { onCellClick(position) }
                        )
                    }
                }
            }
        }
    }
}

/**
 * Una cel·la individual del tauler.
 *
 * @param card          Carta que conté (null si buida)
 * @param isDropTarget  Si és objectiu de col·locació (ressalta)
 * @param cellSize      Mida de la cel·la
 * @param onClick       Callback en prémer
 */
@Composable
private fun BoardCell(
    card: Card?,
    isDropTarget: Boolean,
    cellSize: Dp,
    onClick: () -> Unit
) {
    val bgColor     = if (isDropTarget) CellHover else CellEmpty
    val borderColor = when {
        isDropTarget -> SecondaryGold.copy(alpha = 0.7f)
        else         -> Color(0xFF2A3050)
    }

    Box(
        modifier          = Modifier.size(cellSize),
        contentAlignment  = Alignment.Center
    ) {
        if (card == null) {
            // Cel·la buida (potencialment seleccionable)
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(bgColor, RoundedCornerShape(6.dp))
                    .border(
                        width = if (isDropTarget) 2.dp else 1.dp,
                        color = borderColor,
                        shape = RoundedCornerShape(6.dp)
                    )
                    .then(
                        if (isDropTarget) Modifier.clickable(onClick = onClick)
                        else Modifier
                    )
            )
        } else {
            // Cel·la amb carta
            CardComponent(
                card      = card,
                onClick   = null,    // no clickable quan ja hi ha carta
                cardSize  = cellSize
            )
        }
    }
}
