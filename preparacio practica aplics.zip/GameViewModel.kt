package com.example.tripletriad.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.tripletriad.model.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

// ────────────────────────────────────────────────
// ENUM auxiliar per indicar la direcció d'adjacència
// ────────────────────────────────────────────────
enum class Direction { TOP, BOTTOM, LEFT, RIGHT }

/**
 * GameViewModel
 *
 * Conté TOTA la lògica del joc:
 *  - Inicialització de la partida
 *  - Selecció i col·locació de cartes (jugador)
 *  - IA de la CPU
 *  - Lògica de captura
 *  - Control del temporitzador per coroutines
 *  - Generació del log de partida
 *
 * Sobreviu a rotacions de pantalla (ViewModel del cicle de vida d'Activity).
 */
class GameViewModel : ViewModel() {

    // ─────────────────────────────
    // STATE FLOWS (exposats a la UI)
    // ─────────────────────────────

    private val _config = MutableStateFlow(GameConfig())
    val config: StateFlow<GameConfig> = _config.asStateFlow()

    private val _gameState = MutableStateFlow(GameState())
    val gameState: StateFlow<GameState> = _gameState.asStateFlow()

    // ─────────────────────────────
    // ESTAT INTERN
    // ─────────────────────────────

    private var timerJob: Job? = null
    private var gameStartTime: Long = 0L

    // ─────────────────────────────
    // MAZO DE CARTES PREDEFINIT
    // Inspirat en Triple Triad (FF8)
    // ─────────────────────────────

    private val allCards = listOf(
        Card(1,  "Geezard",       top = 1, right = 4, bottom = 1, left = 5),
        Card(2,  "Funguar",       top = 5, right = 1, bottom = 3, left = 1),
        Card(3,  "Bite Bug",      top = 1, right = 5, bottom = 3, left = 3),
        Card(4,  "Red Bat",       top = 6, right = 2, bottom = 1, left = 1),
        Card(5,  "Blobra",        top = 2, right = 3, bottom = 4, left = 5),
        Card(6,  "Gayla",         top = 2, right = 4, bottom = 4, left = 4),
        Card(7,  "Gesper",        top = 1, right = 5, bottom = 3, left = 4),
        Card(8,  "Fastitocalon",  top = 3, right = 1, bottom = 5, left = 4),
        Card(9,  "Blood Soul",    top = 2, right = 6, bottom = 1, left = 1),
        Card(10, "Caterchipillar",top = 4, right = 3, bottom = 4, left = 3),
        Card(11, "Cockatrice",    top = 2, right = 5, bottom = 4, left = 3),
        Card(12, "Grat",          top = 7, right = 1, bottom = 1, left = 3),
        Card(13, "Buel",          top = 6, right = 3, bottom = 2, left = 3),
        Card(14, "Mesmerize",     top = 5, right = 4, bottom = 4, left = 1),
        Card(15, "Glacial Eye",   top = 6, right = 3, bottom = 1, left = 4),
        Card(16, "Belhelmel",     top = 3, right = 3, bottom = 4, left = 5),
        Card(17, "Thrustaevis",   top = 5, right = 5, bottom = 3, left = 2),
        Card(18, "Anacondaur",    top = 5, right = 3, bottom = 5, left = 1),
        Card(19, "Creeps",        top = 5, right = 2, bottom = 5, left = 2),
        Card(20, "Grendel",       top = 4, right = 4, bottom = 4, left = 4),
    )

    // ══════════════════════════════════════════════
    // MÈTODES DE CONFIGURACIÓ
    // ══════════════════════════════════════════════

    fun updatePlayerAlias(alias: String) {
        _config.update { it.copy(playerAlias = alias) }
    }

    fun updateTimerEnabled(enabled: Boolean) {
        _config.update { it.copy(timerEnabled = enabled) }
    }

    fun updateMaxTime(seconds: Int) {
        _config.update { it.copy(maxTimeSeconds = seconds.coerceIn(10, 120)) }
    }

    // ══════════════════════════════════════════════
    // INICIALITZACIÓ DE LA PARTIDA
    // ══════════════════════════════════════════════

    /**
     * Inicia una nova partida:
     * - Reseteja l'estat
     * - Distribueix 5 cartes a cada jugador
     * - Arrenca el timer si està configurat
     */
    fun startGame() {
        timerJob?.cancel()
        gameStartTime = System.currentTimeMillis()

        val shuffled = allCards.shuffled()
        val playerCards = shuffled.take(5).map { it.copy(owner = CardOwner.PLAYER) }
        val cpuCards    = shuffled.drop(5).take(5).map { it.copy(owner = CardOwner.CPU) }
        val initTime    = if (_config.value.timerEnabled) _config.value.maxTimeSeconds else 0
        val timeStr     = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())

        _gameState.value = GameState(
            board             = List(9) { null },
            playerHand        = playerCards,
            cpuHand           = cpuCards,
            currentTurn       = CardOwner.PLAYER,
            playerScore       = 5,
            cpuScore          = 5,
            isGameOver        = false,
            winner            = CardOwner.NONE,
            selectedCardIndex = null,
            timeRemaining     = initTime,
            moveLog           = listOf("=== Partida iniciada ($timeStr) ==="),
            totalMovesCount   = 0
        )

        if (_config.value.timerEnabled) startTimer(initTime)
    }

    // ══════════════════════════════════════════════
    // ACCIONS DEL JUGADOR
    // ══════════════════════════════════════════════

    /**
     * Selecciona una carta de la mà del jugador.
     * Només és vàlid durant el torn del jugador.
     */
    fun selectCard(index: Int) {
        val state = _gameState.value
        if (state.isGameOver || state.currentTurn != CardOwner.PLAYER) return
        if (index !in state.playerHand.indices) return
        _gameState.update { it.copy(selectedCardIndex = index) }
    }

    /**
     * Col·loca la carta seleccionada al tauler.
     * Processa les captures i cedeix el torn a la CPU.
     *
     * @param boardPosition Posició al tauler (0-8), esquerra-dreta, dalt-baix
     */
    fun placeCard(boardPosition: Int) {
        val state = _gameState.value

        // Guards de seguretat
        if (state.isGameOver) return
        if (state.currentTurn != CardOwner.PLAYER) return
        if (state.board[boardPosition] != null) return        // cel·la ja ocupada
        val selectedIndex = state.selectedCardIndex ?: return // cap carta seleccionada
        if (selectedIndex !in state.playerHand.indices) return

        // Col·loca la carta
        val card     = state.playerHand[selectedIndex].copy(owner = CardOwner.PLAYER)
        val newBoard = state.board.toMutableList().also { it[boardPosition] = card }
        val moveMsg  = "T${state.totalMovesCount + 1}: ${_config.value.playerAlias} → ${card.name} [pos $boardPosition]"

        // Processa captures
        val (capturedBoard, captureLogs) = processCaptures(newBoard, boardPosition, CardOwner.PLAYER)

        // Actualitza la mà i puntuació
        val newPlayerHand = state.playerHand.toMutableList().also { it.removeAt(selectedIndex) }
        val (pScore, cScore) = calculateScores(capturedBoard, newPlayerHand, state.cpuHand)

        val updated = state.copy(
            board             = capturedBoard,
            playerHand        = newPlayerHand,
            selectedCardIndex = null,
            currentTurn       = CardOwner.CPU,
            moveLog           = state.moveLog + moveMsg + captureLogs,
            playerScore       = pScore,
            cpuScore          = cScore,
            totalMovesCount   = state.totalMovesCount + 1
        )

        val final = checkGameOver(updated)
        _gameState.value = final

        if (!final.isGameOver) {
            // Reinicia el timer per al torn de la CPU si cal
            if (_config.value.timerEnabled) startTimer(_config.value.maxTimeSeconds)
            scheduleCpuTurn()
        } else {
            timerJob?.cancel()
        }
    }

    // ══════════════════════════════════════════════
    // IA DE LA CPU
    // ══════════════════════════════════════════════

    /**
     * Programa el torn de la CPU amb un retard per simular "pensament".
     */
    private fun scheduleCpuTurn() {
        viewModelScope.launch {
            delay(850L)
            executeCpuTurn()
        }
    }

    /**
     * Executa el torn de la CPU:
     * 1. Intenta maximitzar captures
     * 2. Si empat, tria posició que protegeixi les seves cartes
     * 3. Si tot igual, aleatòria
     */
    private fun executeCpuTurn() {
        val state = _gameState.value
        if (state.isGameOver || state.currentTurn != CardOwner.CPU) return
        if (state.cpuHand.isEmpty()) return

        val emptyPos = state.board.indices.filter { state.board[it] == null }
        if (emptyPos.isEmpty()) return

        // Cerca el millor moviment
        data class Move(val handIdx: Int, val pos: Int, val captures: Int)

        val bestMove = state.cpuHand.indices
            .flatMap { hIdx -> emptyPos.map { pos ->
                Move(hIdx, pos, countCaptures(state.board, state.cpuHand[hIdx], pos, CardOwner.CPU))
            }}
            // Prioritza captures; a igualtat, tria el que menys exposat queda
            .maxWithOrNull(Comparator { a, b ->
                if (a.captures != b.captures) a.captures - b.captures
                else {
                    val exposA = exposureScore(state.board, state.cpuHand[a.handIdx], a.pos, state.playerHand)
                    val exposB = exposureScore(state.board, state.cpuHand[b.handIdx], b.pos, state.playerHand)
                    exposA - exposB  // menys exposat = millor
                }
            }) ?: Move(0, emptyPos.first(), 0)

        // Col·loca la carta
        val card     = state.cpuHand[bestMove.handIdx].copy(owner = CardOwner.CPU)
        val newBoard = state.board.toMutableList().also { it[bestMove.pos] = card }
        val moveMsg  = "T${state.totalMovesCount + 1}: CPU → ${card.name} [pos ${bestMove.pos}]"

        val (capturedBoard, captureLogs) = processCaptures(newBoard, bestMove.pos, CardOwner.CPU)
        val newCpuHand = state.cpuHand.toMutableList().also { it.removeAt(bestMove.handIdx) }
        val (pScore, cScore) = calculateScores(capturedBoard, state.playerHand, newCpuHand)

        val updated = state.copy(
            board           = capturedBoard,
            cpuHand         = newCpuHand,
            currentTurn     = CardOwner.PLAYER,
            moveLog         = state.moveLog + moveMsg + captureLogs,
            playerScore     = pScore,
            cpuScore        = cScore,
            totalMovesCount = state.totalMovesCount + 1
        )

        val final = checkGameOver(updated)
        _gameState.value = final

        if (final.isGameOver) {
            timerJob?.cancel()
        } else if (_config.value.timerEnabled) {
            startTimer(_config.value.maxTimeSeconds)
        }
    }

    /**
     * Calcula quantes captures faria col·locar [card] a [position].
     */
    private fun countCaptures(board: List<Card?>, card: Card, position: Int, owner: CardOwner): Int =
        getAdjacent(position)
            .mapNotNull { (dir, pos) -> board.getOrNull(pos)?.takeIf { it.owner != owner }?.let { dir to it } }
            .count { (dir, adj) -> beats(card, adj, dir) }

    /**
     * Puntuació d'exposició: quantes de les cartes del jugador podrien
     * capturar la carta CPU si la posem a [position].
     * Un valor més baix és millor per a la CPU.
     */
    private fun exposureScore(
        board: List<Card?>, cpuCard: Card, position: Int, playerHand: List<Card>
    ): Int {
        var risk = 0
        getAdjacent(position).forEach { (dir, _) ->
            playerHand.forEach { pCard ->
                if (beats(pCard, cpuCard, dir)) risk++
            }
        }
        return -risk  // negatiu per invertir l'ordenació
    }

    // ══════════════════════════════════════════════
    // LÒGICA DE CAPTURES
    // ══════════════════════════════════════════════

    /**
     * Processa totes les captures possibles al voltant de [position].
     * Retorna el tauler actualitzat i una llista de missatges de log.
     */
    private fun processCaptures(
        board: MutableList<Card?>,
        position: Int,
        owner: CardOwner
    ): Pair<List<Card?>, List<String>> {
        val placed   = board[position] ?: return Pair(board, emptyList())
        val ownerStr = if (owner == CardOwner.PLAYER) _config.value.playerAlias else "CPU"
        val logs     = mutableListOf<String>()

        getAdjacent(position).forEach { (dir, adjPos) ->
            val adj = board.getOrNull(adjPos) ?: return@forEach
            if (adj.owner == owner) return@forEach          // mateixa propietat, no capturem

            if (beats(placed, adj, dir)) {
                board[adjPos] = adj.copy(owner = owner)
                logs += "  ↳ $ownerStr captura ${adj.name}! " +
                        "(${dirName(dir)}: ${valFor(placed, dir)} > ${valOpposite(adj, dir)})"
            }
        }

        return Pair(board.toList(), logs)
    }

    /**
     * Retorna true si [attacker] guanya contra [defender] en la direcció [dir].
     * Regla: el valor de l'atacant en aquella direcció > valor oposat del defensor.
     */
    private fun beats(attacker: Card, defender: Card, dir: Direction): Boolean =
        when (dir) {
            Direction.TOP    -> attacker.top    > defender.bottom
            Direction.BOTTOM -> attacker.bottom > defender.top
            Direction.LEFT   -> attacker.left   > defender.right
            Direction.RIGHT  -> attacker.right  > defender.left
        }

    /**
     * Retorna les posicions adjacents vàlides i la seva direcció relativa.
     *
     * Distribució del tauler (índexos 0-8):
     *  ┌───┬───┬───┐
     *  │ 0 │ 1 │ 2 │
     *  ├───┼───┼───┤
     *  │ 3 │ 4 │ 5 │
     *  ├───┼───┼───┤
     *  │ 6 │ 7 │ 8 │
     *  └───┴───┴───┘
     */
    private fun getAdjacent(position: Int): List<Pair<Direction, Int>> {
        val row = position / 3
        val col = position % 3
        return buildList {
            if (row > 0) add(Direction.TOP    to position - 3)
            if (row < 2) add(Direction.BOTTOM to position + 3)
            if (col > 0) add(Direction.LEFT   to position - 1)
            if (col < 2) add(Direction.RIGHT  to position + 1)
        }
    }

    // Helpers per obtenir valors de la carta per cada direcció
    private fun valFor(card: Card, dir: Direction) = when (dir) {
        Direction.TOP    -> card.top
        Direction.BOTTOM -> card.bottom
        Direction.LEFT   -> card.left
        Direction.RIGHT  -> card.right
    }
    private fun valOpposite(card: Card, dir: Direction) = when (dir) {
        Direction.TOP    -> card.bottom
        Direction.BOTTOM -> card.top
        Direction.LEFT   -> card.right
        Direction.RIGHT  -> card.left
    }
    private fun dirName(dir: Direction) = when (dir) {
        Direction.TOP    -> "↑"
        Direction.BOTTOM -> "↓"
        Direction.LEFT   -> "←"
        Direction.RIGHT  -> "→"
    }

    // ══════════════════════════════════════════════
    // PUNTUACIÓ I FI DE PARTIDA
    // ══════════════════════════════════════════════

    /**
     * Calcula la puntuació de cada jugador:
     * Cartes al tauler + cartes a la mà (total sempre = 10)
     */
    private fun calculateScores(
        board: List<Card?>, playerHand: List<Card>, cpuHand: List<Card>
    ): Pair<Int, Int> = Pair(
        board.count { it?.owner == CardOwner.PLAYER } + playerHand.size,
        board.count { it?.owner == CardOwner.CPU    } + cpuHand.size
    )

    /**
     * Comprova si la partida ha acabat (tauler ple o mans buides).
     * Si és així, determina el guanyador i tanca el log.
     */
    private fun checkGameOver(state: GameState): GameState {
        val boardFull  = state.board.none { it == null }
        val handsEmpty = state.playerHand.isEmpty() && state.cpuHand.isEmpty()
        if (!boardFull && !handsEmpty) return state

        val winner = when {
            state.playerScore > state.cpuScore -> CardOwner.PLAYER
            state.cpuScore > state.playerScore -> CardOwner.CPU
            else                               -> CardOwner.NONE
        }

        val resultMsg = when (winner) {
            CardOwner.PLAYER -> "VICTÒRIA! ${_config.value.playerAlias} guanya ${state.playerScore}-${state.cpuScore}"
            CardOwner.CPU    -> "DERROTA. CPU guanya ${state.cpuScore}-${state.playerScore}"
            CardOwner.NONE   -> "EMPAT! ${state.playerScore}-${state.cpuScore}"
        }

        return state.copy(
            isGameOver = true,
            winner     = winner,
            moveLog    = state.moveLog + "=== Fi de la partida ===" + resultMsg
        )
    }

    // ══════════════════════════════════════════════
    // TEMPORITZADOR
    // ══════════════════════════════════════════════

    /**
     * Inicia el countdown timer per al torn actual.
     * Usa coroutines (viewModelScope) per no bloquejar el main thread.
     */
    private fun startTimer(seconds: Int) {
        timerJob?.cancel()
        _gameState.update { it.copy(timeRemaining = seconds) }

        timerJob = viewModelScope.launch {
            for (remaining in seconds downTo 0) {
                _gameState.update { it.copy(timeRemaining = remaining) }
                if (remaining == 0) {
                    handleTimeOut()
                    break
                }
                delay(1_000L)
            }
        }
    }

    /**
     * Gestiona el final del temps: força el final de partida.
     */
    private fun handleTimeOut() {
        val state = _gameState.value
        if (state.isGameOver) return

        val winner = when {
            state.playerScore > state.cpuScore -> CardOwner.PLAYER
            state.cpuScore > state.playerScore -> CardOwner.CPU
            else                               -> CardOwner.NONE
        }

        _gameState.update { s ->
            val resultMsg = when (winner) {
                CardOwner.PLAYER -> "VICTÒRIA per temps!"
                CardOwner.CPU    -> "DERROTA per temps!"
                CardOwner.NONE   -> "EMPAT per temps!"
            }
            s.copy(
                isGameOver = true,
                winner     = winner,
                moveLog    = s.moveLog + "⏰ Temps esgotat!" + resultMsg
            )
        }
    }

    // ══════════════════════════════════════════════
    // GENERACIÓ DEL LOG
    // ══════════════════════════════════════════════

    /**
     * Genera el log complet de la partida en format text.
     * Inclou capçalera, estadístiques i tots els moviments.
     */
    fun generateGameLog(): String {
        val state      = _gameState.value
        val cfg        = _config.value
        val elapsedSec = (System.currentTimeMillis() - gameStartTime) / 1_000
        val dateStr    = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(Date())

        return buildString {
            appendLine("╔══════════════════════════════╗")
            appendLine("║      LOG DE PARTIDA TT       ║")
            appendLine("╚══════════════════════════════╝")
            appendLine()
            appendLine("Data:          $dateStr")
            appendLine("Jugador:       ${cfg.playerAlias}")
            appendLine("Temps total:   ${elapsedSec}s")
            appendLine("Timer actiu:   ${if (cfg.timerEnabled) "Sí (${cfg.maxTimeSeconds}s/torn)" else "No"}")
            appendLine("Moviments:     ${state.totalMovesCount}")
            appendLine()
            appendLine("PUNTUACIÓ FINAL")
            appendLine("  ${cfg.playerAlias.padEnd(12)}: ${state.playerScore} cartes")
            appendLine("  CPU           : ${state.cpuScore} cartes")
            appendLine()
            appendLine("RESULTAT: ${when (state.winner) {
                CardOwner.PLAYER -> "VICTÒRIA (\uD83C\uDFC6)"
                CardOwner.CPU    -> "DERROTA"
                CardOwner.NONE   -> "EMPAT"
            }}")
            appendLine()
            appendLine("──────────────────────────────")
            appendLine("REGISTRE DE MOVIMENTS:")
            appendLine()
            state.moveLog.forEach { appendLine(it) }
        }
    }

    // ══════════════════════════════════════════════
    // NETEJA
    // ══════════════════════════════════════════════

    override fun onCleared() {
        super.onCleared()
        timerJob?.cancel()
    }
}
