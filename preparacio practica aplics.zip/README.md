# Triple Triad — Guia d'implementació a Android Studio

## Estructura de fitxers al projecte

```
app/
└── src/main/
    ├── AndroidManifest.xml
    ├── java/com/example/tripletriad/
    │   │
    │   ├── MainActivity.kt                      ← Punt d'entrada
    │   │
    │   ├── model/
    │   │   ├── Card.kt                          ← Data class: carta amb 4 valors
    │   │   ├── GameConfig.kt                    ← Data class: configuració partida
    │   │   └── GameState.kt                     ← Data class: estat complet del joc
    │   │
    │   ├── viewmodel/
    │   │   └── GameViewModel.kt                 ← TOTA la lògica del joc
    │   │
    │   ├── navigation/
    │   │   └── AppNavigation.kt                 ← NavHost + Screen sealed class
    │   │
    │   └── ui/
    │       ├── theme/
    │       │   ├── Color.kt                     ← Paleta de colors
    │       │   ├── Theme.kt                     ← MaterialTheme (dark)
    │       │   └── Type.kt                      ← Tipografia
    │       │
    │       ├── components/
    │       │   ├── CardComponent.kt             ← Carta visual (top/right/bot/left)
    │       │   └── GameBoardComponent.kt        ← Tauler 3x3 interactiu
    │       │
    │       └── screens/
    │           ├── MainMenuScreen.kt            ← Menú principal
    │           ├── ConfigScreen.kt              ← Configuració (alias, timer)
    │           ├── GameScreen.kt                ← Pantalla de joc
    │           ├── ResultScreen.kt              ← Resultats + email
    │           └── HelpScreen.kt               ← Explicació de les regles
    │
    └── res/
        └── values/
            ├── strings.xml                      ← TOTS els strings (sense hardcoding)
            └── themes.xml                       ← Tema XML de la Activity
```

---

## Passos per crear el projecte a Android Studio

### 1. Crear el projecte
- **File → New → New Project**
- Template: **Empty Activity** (no "Empty Compose Activity")
- Name: `TripleTriad`
- Package: `com.example.tripletriad`
- Language: **Kotlin**
- Minimum SDK: **API 26 (Android 8.0)**

### 2. Copiar els fitxers

Copia cada fitxer al directori corresponent seguint l'estructura de dalt.

> ⚠️ **IMPORTANT**: Assegura't que el `package` al principi de cada fitxer
> coincideix exactament amb el teu package del projecte.

### 3. Actualitzar `build.gradle.kts` (app)

Substitueix el contingut amb el fitxer `build.gradle.kts` d'aquest projecte.
Sincronitza el projecte: **File → Sync Project with Gradle Files**

### 4. Actualitzar `libs.versions.toml`

Si el teu projecte usa Version Catalogs (`gradle/libs.versions.toml`),
copia el contingut del fitxer `libs.versions.toml` d'aquest projecte.

### 5. Actualitzar `res/values/`

- Substitueix `strings.xml` pel fitxer d'aquest projecte
- Substitueix `themes.xml` pel fitxer d'aquest projecte

---

## Dependències requerides

Totes s'afegeixen via `build.gradle.kts`:

| Dependència | Versió | Ús |
|-------------|--------|----|
| Navigation Compose | 2.8.9 | Navegació entre pantalles |
| ViewModel Compose | 2.8.7 | ViewModel Activity-scoped |
| Lifecycle Runtime Compose | 2.8.7 | collectAsState() |
| Coroutines Android | 1.9.0 | Timer async |
| Material Icons Extended | BOM | Icona ArrowBack |
| Compose BOM | 2024.12.01 | Totes les versions Compose |

---

## Arquitectura MVVM

```
UI (Composable)          ViewModel               Model
─────────────────        ──────────────────      ─────────────────
MainMenuScreen    ──────►  GameViewModel  ──────► GameState
ConfigScreen      ──────►    (lògica)     ──────► GameConfig
GameScreen        ◄──────    StateFlow    ◄──────  Card
ResultScreen      ◄──────    (estat)
HelpScreen
```

### Flux de dades:
1. **UI observa** `viewModel.gameState.collectAsState()` → re-composició reactiva
2. **UI crida** mètodes del ViewModel (`placeCard`, `selectCard`, etc.)
3. **ViewModel actualitza** `_gameState` via `MutableStateFlow.update { }`
4. **ViewModel sobreviu** a rotacions (creat amb `by viewModels()` a l'Activity)

---

## Mecànica de captura (lògica clau)

```
Col·loca carta [A] a la posició 4 (centre):

        [?]            Compara:
       [?][A][?]       A.top    > carta[1].bottom → captura si cert
        [?]            A.right  > carta[5].left   → captura si cert
                       A.bottom > carta[7].top    → captura si cert
                       A.left   > carta[3].right  → captura si cert
```

Implementat a `GameViewModel.processCaptures()` i `beats()`.

---

## Gestió d'estat en rotació

```kotlin
// MainActivity.kt — ViewModel Activity-scoped
private val gameViewModel: GameViewModel by viewModels()
//                                         ^^^^^^^^^^^
// Sobreviu a rotacions. NO usar viewModel() dins un Composable directament
// per a l'estat global, sinó passar-lo des de l'Activity.
```

---

## Timer (coroutines)

```kotlin
// GameViewModel.kt
private fun startTimer(seconds: Int) {
    timerJob?.cancel()   // Cancel el timer anterior
    timerJob = viewModelScope.launch {
        for (remaining in seconds downTo 0) {
            _gameState.update { it.copy(timeRemaining = remaining) }
            if (remaining == 0) { handleTimeOut(); break }
            delay(1_000L)
        }
    }
}
```

El `viewModelScope` es cancel·la automàticament quan el ViewModel es destrueix.

---

## Email Intent

```kotlin
// ResultScreen.kt
val intent = Intent(Intent.ACTION_SEND).apply {
    type = "text/plain"
    putExtra(Intent.EXTRA_EMAIL,   arrayOf(emailAddress))
    putExtra(Intent.EXTRA_SUBJECT, "Log Triple Triad - $dateStr")
    putExtra(Intent.EXTRA_TEXT,    gameLog)
}
context.startActivity(Intent.createChooser(intent, "Enviar log"))
```

---

## Navegació (backstack net)

| Transició | `popUpTo` | Efecte |
|-----------|-----------|--------|
| Config → Game | `Config` inclusive | No torna a Config |
| Game → Result | `Game` inclusive | No torna a la partida |
| Result → Menu | `startDestination` | Neteja tot el backstack |

---

## Punts importants per la nota

- ✅ **Cap lògica als Composable** — tot al ViewModel
- ✅ **Strings externalitzats** — cap hardcoding
- ✅ **Control de nulls** — `?.`, `?: return`, `getOrNull()`
- ✅ **Rotació** — ViewModel Activity-scoped + StateFlow
- ✅ **Timer** — coroutines amb cancel·lació correcta
- ✅ **UI responsive** — `BoxWithConstraints` adapta el tauler
- ✅ **Material3** — `MaterialTheme`, `Scaffold`, `Card`, etc.
