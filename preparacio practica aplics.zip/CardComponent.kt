package com.example.tripletriad.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tripletriad.model.Card
import com.example.tripletriad.model.CardOwner
import com.example.tripletriad.ui.theme.*

/**
 * Component visual d'una carta Triple Triad.
 *
 * Mostra:
 *  - Nom de la carta (centrat)
 *  - Els 4 valors en posició T/R/B/L
 *  - Color de fons segons el propietari
 *  - Vora ressaltada si la carta és seleccionada
 *
 * @param card          La carta a mostrar (null = carta al revés / oculta per CPU)
 * @param isSelected    Si la carta està seleccionada
 * @param isHidden      Si s'ha de mostrar oculta (per a la mà de la CPU)
 * @param onClick       Callback en fer clic
 * @param cardSize      Mida del component
 */
@Composable
fun CardComponent(
    card: Card?,
    isSelected: Boolean = false,
    isHidden: Boolean = false,
    onClick: (() -> Unit)? = null,
    cardSize: Dp = 80.dp
) {
    val shape = RoundedCornerShape(8.dp)

    // Colors basats en el propietari
    val bgColor = when {
        card == null      -> SurfaceCard
        isHidden          -> Color(0xFF1A2035)
        else -> when (card.owner) {
            CardOwner.PLAYER -> PlayerCardColor
            CardOwner.CPU    -> CpuCardColor
            CardOwner.NONE   -> NeutralCardColor
        }
    }
    val borderColor = when {
        isSelected        -> SecondaryGold
        card == null      -> Color(0xFF2A3050)
        isHidden          -> Color(0xFF2A3050)
        else -> when (card.owner) {
            CardOwner.PLAYER -> PlayerCardBorder
            CardOwner.CPU    -> CpuCardBorder
            CardOwner.NONE   -> Color(0xFF546E7A)
        }
    }
    val borderWidth = if (isSelected) 2.dp else 1.dp

    Box(
        modifier = Modifier
            .size(cardSize)
            .clip(shape)
            .background(bgColor)
            .border(borderWidth, borderColor, shape)
            .then(
                if (onClick != null) Modifier.clickable(onClick = onClick)
                else Modifier
            )
    ) {
        if (card == null || isHidden) {
            // Carta buida o oculta
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text  = if (card == null) "" else "?",
                    color = Color(0xFF546E7A),
                    style = MaterialTheme.typography.titleLarge
                )
            }
        } else {
            // Carta visible amb valors
            val valueSize    = (cardSize.value * 0.18f).sp
            val nameFontSize = (cardSize.value * 0.11f).sp
            val padding      = (cardSize.value * 0.06f).dp

            // Valor TOP (centre-dalt)
            CardValue(
                value    = card.top,
                fontSize = valueSize,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = padding)
            )

            // Valor BOTTOM (centre-baix)
            CardValue(
                value    = card.bottom,
                fontSize = valueSize,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = padding)
            )

            // Valor LEFT (centre-esquerra)
            CardValue(
                value    = card.left,
                fontSize = valueSize,
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .padding(start = padding)
            )

            // Valor RIGHT (centre-dreta)
            CardValue(
                value    = card.right,
                fontSize = valueSize,
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = padding)
            )

            // Nom de la carta (centre)
            Text(
                text      = card.name,
                fontSize  = nameFontSize,
                color     = Color.White.copy(alpha = 0.85f),
                maxLines  = 2,
                overflow  = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                lineHeight = nameFontSize * 1.2f,
                modifier  = Modifier
                    .align(Alignment.Center)
                    .padding(horizontal = (cardSize.value * 0.14f).dp)
            )
        }
    }
}

/**
 * Text amb el valor numèric d'una carta (1-10).
 * El valor 10 es mostra com "A" (As) per conveni de Triple Triad.
 */
@Composable
private fun CardValue(
    value: Int,
    fontSize: androidx.compose.ui.unit.TextUnit,
    modifier: Modifier = Modifier
) {
    Text(
        text       = if (value == 10) "A" else value.toString(),
        fontSize   = fontSize,
        fontWeight = FontWeight.Bold,
        color      = Color.White,
        modifier   = modifier
    )
}
