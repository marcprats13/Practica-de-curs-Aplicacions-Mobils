package com.example.tripletriad.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.example.tripletriad.R
import com.example.tripletriad.model.CardOwner
import com.example.tripletriad.navigation.Screen
import com.example.tripletriad.ui.theme.*
import com.example.tripletriad.viewmodel.GameViewModel
import java.text.SimpleDateFormat
import java.util.*

/**
 * Pantalla de resultats de la partida.
 *
 * Mostra:
 *  - Banner de resultat (Victòria / Derrota / Empat)
 *  - Estadístiques (puntuació final, moviments, etc.)
 *  - Log complet de la partida (desplaçable)
 *  - TextField per a l'adreça d'email
 *  - Botó d'enviament d'email (Intent ACTION_SEND)
 *  - Botó per tornar al menú principal
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResultScreen(
    navController: NavHostController,
    viewModel: GameViewModel
) {
    val context   = LocalContext.current
    val gameState by viewModel.gameState.collectAsState()
    val config    by viewModel.config.collectAsState()

    // Log generat una sola vegada
    val gameLog = remember { viewModel.generateGameLog() }

    // Estat local per al TextField d'email
    var emailAddress by remember { mutableStateOf("") }
    var emailError   by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title  = { Text(stringResource(R.string.screen_result_title)) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SurfaceDark
                )
            )
        },
        containerColor = BackgroundDark
    ) { innerPadding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {

            // ══ BANNER DE RESULTAT ════════════════════════════════════
            ResultBanner(winner = gameState.winner, playerAlias = config.playerAlias)

            // ══ ESTADÍSTIQUES ════════════════════════════════════════
            StatisticsCard(
                playerAlias   = config.playerAlias,
                playerScore   = gameState.playerScore,
                cpuScore      = gameState.cpuScore,
                totalMoves    = gameState.totalMovesCount,
                timerEnabled  = config.timerEnabled,
                maxTime       = config.maxTimeSeconds
            )

            // ══ LOG DE LA PARTIDA ════════════════════════════════════
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors   = CardDefaults.cardColors(containerColor = SurfaceCard)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text  = stringResource(R.string.result_log_title),
                        style = MaterialTheme.typography.titleMedium,
                        color = SecondaryGold
                    )
                    Spacer(Modifier.height(8.dp))

                    // Log en monospace, amb scroll propi
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(220.dp)
                            .background(BackgroundDark, MaterialTheme.shapes.small)
                            .padding(8.dp)
                    ) {
                        Text(
                            text       = gameLog,
                            fontSize   = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color      = OnBackground,
                            modifier   = Modifier.verticalScroll(rememberScrollState())
                        )
                    }
                }
            }

            // ══ ENVIAMENT D'EMAIL ════════════════════════════════════
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors   = CardDefaults.cardColors(containerColor = SurfaceCard)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text  = stringResource(R.string.result_email_section),
                        style = MaterialTheme.typography.titleMedium,
                        color = SecondaryGold
                    )

                    OutlinedTextField(
                        value         = emailAddress,
                        onValueChange = { addr ->
                            emailAddress = addr
                            emailError   = addr.isNotEmpty() && !android.util.Patterns.EMAIL_ADDRESS.matcher(addr).matches()
                        },
                        label         = { Text(stringResource(R.string.result_email_label)) },
                        placeholder   = { Text(stringResource(R.string.result_email_placeholder)) },
                        isError       = emailError,
                        supportingText = {
                            if (emailError) Text(
                                text  = stringResource(R.string.result_email_error),
                                color = MaterialTheme.colorScheme.error
                            )
                        },
                        singleLine    = true,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Email,
                            imeAction    = ImeAction.Send
                        ),
                        modifier = Modifier.fillMaxWidth(),
                        colors   = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor   = PrimaryBlueLight,
                            unfocusedBorderColor = OnSurface.copy(alpha = 0.4f)
                        )
                    )

                    Button(
                        onClick = {
                            // Validació de l'email
                            if (emailAddress.isBlank()) {
                                emailError = true
                                return@Button
                            }
                            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(emailAddress).matches()) {
                                emailError = true
                                return@Button
                            }
                            // Construeix i llença l'intent d'email
                            val dateStr = SimpleDateFormat(
                                "dd/MM/yyyy HH:mm",
                                Locale.getDefault()
                            ).format(Date())
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_EMAIL,   arrayOf(emailAddress))
                                putExtra(Intent.EXTRA_SUBJECT, "Log Triple Triad - $dateStr")
                                putExtra(Intent.EXTRA_TEXT,    gameLog)
                            }
                            context.startActivity(
                                Intent.createChooser(intent, context.getString(R.string.result_email_chooser))
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors   = ButtonDefaults.buttonColors(
                            containerColor = PrimaryBlue
                        )
                    ) {
                        Text(stringResource(R.string.btn_send_email))
                    }
                }
            }

            // ══ TORNAR AL MENÚ ═══════════════════════════════════════
            Button(
                onClick = {
                    navController.navigate(Screen.MainMenu.route) {
                        // Neteja tot el backstack i va al menú
                        popUpTo(navController.graph.startDestinationId) { inclusive = false }
                        launchSingleTop = true
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                colors   = ButtonDefaults.buttonColors(
                    containerColor = SecondaryGoldDark
                )
            ) {
                Text(
                    text     = stringResource(R.string.btn_back_menu),
                    color    = Color.Black,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// ──────────────────────────────────────────────────────────────────────
// COMPONENTS INTERNS DE ResultScreen
// ──────────────────────────────────────────────────────────────────────

@Composable
private fun ResultBanner(winner: CardOwner, playerAlias: String) {
    val (emoji, message, color) = when (winner) {
        CardOwner.PLAYER -> Triple("🏆", "VICTÒRIA!", WinColor)
        CardOwner.CPU    -> Triple("💀", "DERROTA", LoseColor)
        CardOwner.NONE   -> Triple("🤝", "EMPAT", DrawColor)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors   = CardDefaults.cardColors(
            containerColor = color.copy(alpha = 0.15f)
        )
    ) {
        Column(
            modifier            = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(text = emoji, fontSize = 48.sp)
            Text(
                text       = message,
                fontSize   = 28.sp,
                fontWeight = FontWeight.ExtraBold,
                color      = color
            )
            if (winner == CardOwner.PLAYER) {
                Text(
                    text    = playerAlias,
                    color   = color.copy(alpha = 0.8f),
                    fontSize = 16.sp
                )
            }
        }
    }
}

@Composable
private fun StatisticsCard(
    playerAlias: String,
    playerScore: Int,
    cpuScore: Int,
    totalMoves: Int,
    timerEnabled: Boolean,
    maxTime: Int
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors   = CardDefaults.cardColors(containerColor = SurfaceCard)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text  = "Estadístiques",
                style = MaterialTheme.typography.titleMedium,
                color = SecondaryGold
            )

            HorizontalDivider(color = OnSurface.copy(alpha = 0.2f))

            StatRow(label = playerAlias, value = "$playerScore cartes", color = PlayerCardBorder)
            StatRow(label = "CPU",       value = "$cpuScore cartes",    color = CpuCardBorder)
            StatRow(label = "Moviments", value = totalMoves.toString())
            if (timerEnabled) {
                StatRow(label = "Timer", value = "${maxTime}s per torn")
            }
        }
    }
}

@Composable
private fun StatRow(
    label: String,
    value: String,
    color: Color = OnBackground
) {
    Row(
        modifier              = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = OnSurface,    style = MaterialTheme.typography.bodyMedium)
        Text(text = value, color = color,        style = MaterialTheme.typography.bodyMedium,
             fontWeight = FontWeight.SemiBold)
    }
}
